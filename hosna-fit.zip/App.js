
import { useState } from "react";

const foodUnits = ["یک لیوان", "یک قاشق", "یک کف دست", "یک بشقاب"];

const foods = [
  { name: "برنج", caloriePerUnit: 250 },
  { name: "مرغ", caloriePerUnit: 200 },
  { name: "سیب زمینی", caloriePerUnit: 150 },
  { name: "پیتزا", caloriePerUnit: 300 },
  { name: "پاستا پنه", caloriePerUnit: 350 },
];

function App() {
  const [selectedFood, setSelectedFood] = useState(foods[0].name);
  const [selectedUnit, setSelectedUnit] = useState(foodUnits[0]);
  const [entries, setEntries] = useState([]);

  const handleAddFood = () => {
    const food = foods.find(f => f.name === selectedFood);
    const calorie = food.caloriePerUnit;
    const newEntry = {
      food: selectedFood,
      unit: selectedUnit,
      calorie,
    };
    setEntries([...entries, newEntry]);
  };

  const totalCalories = entries.reduce((sum, entry) => sum + entry.calorie, 0);

  return (
    <div style={{ padding: 20, fontFamily: 'sans-serif', background: '#f9f6f1', minHeight: '100vh' }}>
      <h1 style={{ textAlign: 'center' }}>حسنا فیت</h1>
      <div style={{ background: 'white', padding: 20, borderRadius: 16, maxWidth: 400, margin: 'auto' }}>
        <div>
          <label>غذا</label>
          <select value={selectedFood} onChange={(e) => setSelectedFood(e.target.value)} style={{ width: '100%', marginBottom: 10 }}>
            {foods.map((food, index) => (
              <option key={index} value={food.name}>{food.name}</option>
            ))}
          </select>
        </div>

        <div>
          <label>واحد</label>
          <select value={selectedUnit} onChange={(e) => setSelectedUnit(e.target.value)} style={{ width: '100%', marginBottom: 10 }}>
            {foodUnits.map((unit, index) => (
              <option key={index} value={unit}>{unit}</option>
            ))}
          </select>
        </div>

        <button onClick={handleAddFood} style={{ width: '100%', background: '#fbbf24', padding: 10, border: 'none', borderRadius: 12, color: 'white' }}>
          اضافه کن 🍽️
        </button>
      </div>

      <div style={{ maxWidth: 400, margin: 'auto', marginTop: 20 }}>
        <div style={{ background: 'white', padding: 20, borderRadius: 16 }}>
          <h2>لیست غذاها</h2>
          {entries.length === 0 ? (
            <p>غذایی ثبت نشده.</p>
          ) : (
            <ul>
              {entries.map((entry, idx) => (
                <li key={idx} style={{ display: 'flex', justifyContent: 'space-between' }}>
                  <span>{entry.food} ({entry.unit})</span>
                  <span>{entry.calorie} کالری</span>
                </li>
              ))}
            </ul>
          )}
          <hr />
          <p>جمع کل کالری: {totalCalories}</p>
        </div>
      </div>
    </div>
  );
}

export default App;
